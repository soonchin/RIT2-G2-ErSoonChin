/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practical4q3;

/**
 *
 * @author User
 */
public class Practical4Q3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ListInterface l1=new LinkedList();
        l1.add(1);
        l1.add(2);
        //l1.print();
        //l1.add(1, 3);
        //l1.clear();
        //l1.print();
       // l1.remove(2);
       // l1.print();
        //System.out.println(l1.getEntry(3));
        l1.add(1,3);
        l1.print();
    }
    
}
