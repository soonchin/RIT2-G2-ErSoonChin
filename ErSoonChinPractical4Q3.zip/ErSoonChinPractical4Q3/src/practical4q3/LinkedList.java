/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practical4q3;

/**
 *
 * @author User
 */
public class LinkedList<T> implements ListInterface<T> {

    private Node firstNode;
    private Node lastNode;
    private int size;
    
    public LinkedList()
    {
        firstNode=null;
        lastNode=null;
        size = 0 ;
    }
    @Override
    public void add(T newEntry) {
        Node newNode =new Node(newEntry);
        if(isEmpty())
        {
            firstNode= lastNode=newNode;
            firstNode.prev=null;
            lastNode.next=null;
        }
        else
        {
            lastNode.next=newNode;
            newNode.prev=lastNode;
            lastNode=newNode;
            lastNode.next=null;
        }
        size++;
        
    }

    @Override
    public boolean add(int givenPosition, T newEntry) {
        Node newNode = new Node(newEntry);
        int i=1;
        if(givenPosition>size)
        {
            return false;
        }
        else
        {
            Node ref=firstNode;
            while(i!=givenPosition)
            {
                ref=ref.next;
                i++;
            }
            ref.next=newNode;
            newNode.next=lastNode;
            size++;
            return true;   
        }
    }

    @Override
    public T remove(int givenPosition) {
        T result=null;
        if(givenPosition<=size)
        {
            Node ref=firstNode;
            int i=1;
            while(i!=givenPosition)
            {
                ref=ref.next;
                i++;
            }
            
            result=ref.data;
            //problem
            firstNode=ref.next;
            lastNode.prev=firstNode;
            //problem
            return result;
        }
        return result;
    }

    @Override
    public void clear() {
        if(firstNode.next!=null&&lastNode.prev!=null)
        {
            firstNode.data=null;
            lastNode.data=null;
            System.out.print("Clear");
        }
        else
        {
            System.out.print("Data is still here");
        }
    }

    @Override
    public boolean replace(int givenPosition, T newEntry) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public T getEntry(int givePosition) {
        T result =null;
        int i=1;
        if(givePosition<=size)
        {
            Node ref=firstNode;
            while(i!=givePosition)
            {
                ref=ref.next;
                i++;
            }
            result = ref.data;
            return result;
        }
        return result;
    }

    @Override
    public boolean contains(T anEntry) {
        Node ref= firstNode;
        
        for(int i=0;i<size;i++)
        {
            if(anEntry.equals(ref.data))
            {
                return true;
            }
        }
        return false;
    }

    @Override
    public int getNumberOfEntries() {
        return size;
    }

    @Override
    public boolean isEmpty() {
        if(size==0)
        {
            return true;
        }
        return false;
    }
    public void print(){
        if(isEmpty()==false)
        {
            Node ref=firstNode;
            while(ref!=null)
            {
                System.out.print(ref.data);
                ref=ref.next;
            }
        }
        else
        {
            System.out.println("Nothing is here");
        }
        
    }

    private class Node{
        private T data;
        private Node next;
        private Node prev;
        public Node(T data)
        {
            this.data=data;
            next=null;
        }
        public Node(T data, Node next,Node prev)
        {
            this.data=data;
            this.next=next;
            this.prev=prev;
        }

        public T getData() {
            return data;
        }

        public void setData(T data) {
            this.data = data;
        }

        public Node getNext() {
            return next;
        }

        public void setNext(Node next) {
            this.next = next;
        }
        
    }
    
}
